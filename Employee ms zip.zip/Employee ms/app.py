from flask import Flask, render_template, request, redirect, url_for, session, flash
import re
import sqlite3
import smtplib
from email.message import EmailMessage
import random
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "123"

# ---------------- Database Initialization ----------------
def init_db():
    con = sqlite3.connect("test.db")
    cur = con.cursor()
    
    cur.execute('''CREATE TABLE IF NOT EXISTS emptbl(
                    email TEXT PRIMARY KEY,
                    password TEXT,
                    otp TEXT,
                    otpex DATETIME,
                    role TEXT,
                    name TEXT,
                    mobile TEXT,
                    empcode TEXT
                )''')
    cur.execute('''CREATE TABLE IF NOT EXISTS empworkers(
                name TEXT,
                empcode TEXT,
                role TEXT,
                gender TEXT,
                doj DATE,
                bldgrp TEXT,
                supervisor TEXT
                )''')
    cur.execute('''CREATE TABLE IF NOT EXISTS supervisors (
               empcode TEXT PRIMARY KEY,
               name TEXT,
               email TEXT,
               mobile TEXT,
               role TEXT DEFAULT 'supervisor'
                )''')
    cur.execute('''CREATE TABLE IF NOT EXISTS supworkers(
                name TEXT,
                empcode TEXT,
                role TEXT,
                gender TEXT,
                doj DATE,
                bldgrp TEXT
                )''')
    cur.execute('''CREATE TABLE IF NOT EXISTS leave_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                empcode TEXT,
                supervisor_empcode TEXT,
                leave_from DATE,
                leave_to DATE,
                reason TEXT,
                status TEXT DEFAULT 'Pending',
                email_sent INTEGER DEFAULT 0
                )''')

    con.commit()
    con.close()
def send_email_otp(email, otp):
    msg = EmailMessage()
    msg.set_content(f"Your OTP for password reset is: {otp}\nValid for 5 minutes.")
    msg['Subject'] = "Password Reset OTP"
    msg['From'] = "dhanalakshmib772@gmail.com"
    msg['To'] = email

    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login("dhanalakshmib772@gmail.com", "nfujxqwazwliawuf")
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print("Email sending failed:", e)
        return False

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/create", methods=["POST", "GET"])
def create():
    if request.method == "POST":
        try:
            name = request.form['name']
            role = request.form['role']
            email = request.form['email']
            password = request.form['confirmPassword']
            num = request.form['number']
            empid=request.form['empid']
            if len(password) < 10:
                flash("Password must be at least 10 characters long.", "danger")
                return redirect(url_for("create"))
            elif not re.search("[A-Z]", password):
                flash("Password must contain at least one uppercase letter.", "danger")
                return redirect(url_for("create"))
            elif not re.search("[a-z]", password):
                flash("Password must contain at least one lowercase letter.", "danger")
                return redirect(url_for("create"))
            elif not re.search("[!@#$%^&*(),.?]", password):
                flash("Password must contain at least one special character.", "danger")
                return redirect(url_for("create"))

            con = sqlite3.connect("test.db")
            cur = con.cursor()
            cur.execute('INSERT INTO emptbl(email, password, otp, otpex, role, name, mobile,empcode) VALUES (?, ?, ?, ?, ?, ?, ?,?)',
                        (email, password, '', '', role, name, num,empid))
            con.commit()
            con.close()

            flash("Account created successfully!", "success")
            return redirect(url_for("index"))

        except Exception as e:
            print(e)
            flash("Error creating account. Email might already exist.", "danger")
            return redirect(url_for("create"))

    return render_template("create.html")

@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        ro = request.form['role']
        email = request.form['email']
        password = request.form['password']

        con = sqlite3.connect("test.db")
        cur = con.cursor()
        cur.execute("SELECT * FROM emptbl WHERE role=? AND email=? AND password=?", (ro, email, password))
        row = cur.fetchone()
        con.close()

        if row:
            session['empid']=row[7]
            session['name'] = row[5]
            session['role']=row[4]
            return redirect(url_for("check"))
        else:
            flash("Invalid username or password. Please try again.", "danger")
            return render_template("index.html")

    return render_template("index.html")
@app.route("/check")
def check():
    if 'name' in session and 'role' in session:
        role = session['role'].lower()
        if role == "employee":
            return redirect(url_for("emp"))
        elif role == "supervisor":
            return redirect(url_for("supervisor"))
        elif role == "hr":
            return redirect(url_for("hr"))
        else:
            flash("Invalid role. Please log in again.", "danger")
            return redirect(url_for("index"))
    else:
        flash("Session expired. Please log in again.", "warning")
        return redirect(url_for("index"))

@app.route("/back")
def back():
    return redirect(url_for("index"))

@app.route("/forgot_reset", methods=["GET", "POST"])
def forgot_reset():
    message = ""
    email_entered = ""
    show_otp_fields = False

    if request.method == "POST":
        email = request.form.get("email")
        otp_input = request.form.get("otp")
        new_pass = request.form.get("password")
        confirm_pass = request.form.get("confirm_password")
        email_entered = email

        con = sqlite3.connect("test.db")
        cur = con.cursor()
        cur.execute("SELECT otp, otpex FROM emptbl WHERE email=?", (email,))
        row = cur.fetchone()

        if not row:
            message = "Email not registered!"
        else:
            otp_stored, otp_exp = row

            if not otp_input:
                otp = str(random.randint(100000, 999999))
                expiry = datetime.now() + timedelta(minutes=5)
                cur.execute("UPDATE emptbl SET otp=?, otpex=? WHERE email=?", (otp, expiry, email))
                con.commit()
                send_email_otp(email, otp)
                message = "OTP sent to your email!"
                show_otp_fields = True

            else:
                if otp_exp:
                    otp_exp = datetime.strptime(otp_exp, "%Y-%m-%d %H:%M:%S.%f")
                if not otp_exp or datetime.now() > otp_exp:
                    message = "OTP expired! Please request again."
                    show_otp_fields = True
                elif otp_input != otp_stored:
                    message = "Incorrect OTP!"
                    show_otp_fields = True
                elif new_pass != confirm_pass:
                    message = "Passwords do not match!"
                    show_otp_fields = True
                elif len(new_pass) < 10 or not re.search("[A-Z]", new_pass) or not re.search("[a-z]", new_pass) or not re.search("[!@#$%^&*(),.?]", new_pass):
                    message = "Password must be at least 10 chars, include uppercase, lowercase, special char."
                    show_otp_fields = True
                else:
                    cur.execute("UPDATE emplist SET password=?, otp=NULL, otpex=NULL WHERE email=?", (new_pass, email))
                    con.commit()
                    message = "Password reset successfully!"
        con.close()

    return render_template("forgot_reset.html",
                           message=message,
                           email=email_entered,
                           show_otp_fields=show_otp_fields)
@app.route("/hr", methods=["GET", "POST"])
def hr():
    con = sqlite3.connect("test.db")
    cur = con.cursor()

    # Fetch all employees (role = employee)
    cur.execute("SELECT empcode, name, role, email FROM emptbl where role='employee'")
    empworkers = cur.fetchall()

    # Fetch all supervisors
    cur.execute("SELECT empcode, name, role, email FROM emptbl where role='supervisor'")
    supworkers = cur.fetchall()

    # Count total employees
    total_employees = len(empworkers)

    con.close()

    return render_template(
        "hr.html",
        name=session.get('name', 'User'),
        total=total_employees,
        empworkers=empworkers,
        supworkers=supworkers
    )


'''def supervisor():
    return render_template("supervisor.html", name=session.get('name', 'User'))
@app.route("/supervisor_dashboard")
def supervisor_dashboard():
    if 'empid' not in session or session.get('role') != 'supervisor':
        flash("Access denied", "danger")
        return redirect(url_for("index"))
    
    empid = session['empid']
    con = sqlite3.connect("test.db")
    cur = con.cursor()
    cur.execute("""
        SELECT lr.id, e.name, e.empcode, lr.leave_from, lr.leave_to, lr.reason, lr.status
        FROM leave_requests lr
        JOIN empworkers e ON lr.empcode = e.empcode
        WHERE lr.supervisor_empcode=?
        ORDER BY lr.leave_from DESC
    """, (empid,))
    leaves = cur.fetchall()
    con.close()
    return render_template("supervisor_dashboard.html", leaves=leaves)

@app.route("/supervisor_dashboard")
'''
'''@app.route("/supervisor", methods=["GET", "POST"])
def supervisor():
    if 'empid' not in session or session.get('role') != 'supervisor':
        flash("Access denied", "danger")
        return redirect(url_for("index"))
    
    empid = session['empid']
    con = sqlite3.connect("test.db")
    cur = con.cursor()

    # Fetch all leave requests for this supervisor
    cur.execute("""
        SELECT lr.id, e.name, e.empcode, lr.leave_from, lr.leave_to, lr.reason, lr.status
        FROM leave_requests lr
        JOIN empworkers e ON lr.empcode = e.empcode
        WHERE lr.supervisor_empcode=?
        ORDER BY lr.leave_from DESC
    """, (empid,))
    leaves = cur.fetchall()

    # Metrics
    cur.execute("SELECT COUNT(*) FROM empworkers WHERE supervisor=?", (empid,))
    total_team = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM leave_requests WHERE supervisor_empcode=? AND status='Pending'", (empid,))
    pending_leaves = cur.fetchone()[0]

    today = datetime.date.today()
    cur.execute("SELECT COUNT(*) FROM leave_requests WHERE supervisor_empcode=? AND leave_from<=? AND leave_to>=?", (empid, today, today))
    leaves_today = cur.fetchone()[0]

    con.close()
    return render_template("supervisor.html", leaves=leaves, total_team=total_team, pending_leaves=pending_leaves, leaves_today=leaves_today, name=session.get('name'))


@app.route("/supervisor_dashboard")
def supervisor_dashboard():
    if 'empid' not in session or session.get('role') != 'supervisor':
        flash("Access denied", "danger")
        return redirect(url_for("index"))
    
    empid = session['empid']
    con = sqlite3.connect("test.db")
    cur = con.cursor()

    # Fetch all leave requests for this supervisor
    cur.execute("""
        SELECT lr.id, e.name, e.empcode, lr.leave_from, lr.leave_to, lr.reason, lr.status
        FROM leave_requests lr
        JOIN empworkers e ON lr.empcode = e.empcode
        WHERE lr.supervisor_empcode=?
        ORDER BY lr.leave_from DESC
    """, (empid,))
    leaves = cur.fetchall()

    # Metrics
    cur.execute("SELECT COUNT(*) FROM empworkers WHERE supervisor=?", (empid,))
    total_team = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM leave_requests WHERE supervisor_empcode=? AND status='Pending'", (empid,))
    pending_leaves = cur.fetchone()[0]

    today = datetime.today().date()  # <-- fixed line
    cur.execute("SELECT COUNT(*) FROM leave_requests WHERE supervisor_empcode=? AND leave_from<=? AND leave_to>=?", (empid, today, today))
    leaves_today = cur.fetchone()[0]

    con.close()
    return render_template(
        "supervisor_dashboard.html",
        leaves=leaves,
        total_team=total_team,
        pending_leaves=pending_leaves,
        leaves_today=leaves_today,
        name=session.get('name')
    )
'''
'''@app.route("/supervisor", methods=["GET", "POST"])
def supervisor():
    con = sqlite3.connect("test.db")
    cur = con.cursor()

    # Fetch all employees
    cur.execute("SELECT empcode, leave_from, leave_to, reason FROM leave_requests")
    leaves = cur.fetchall()

    con.close()
    return render_template("supervisor.html", name=session.get('name', 'User'),leaves=leaves)
    '''
@app.route("/supervisor", methods=["GET", "POST"])
def supervisor():
    if 'empid' not in session or session.get('role') != 'supervisor':
        flash("Access denied", "danger")
        return redirect(url_for("index"))

    empid = session['empid']
    con = sqlite3.connect("test.db")
    cur = con.cursor()

    if request.method == "POST":
        leave_id = request.form.get("leave_id")
        action = request.form.get("action")  # "Approve" or "Reject"
        if leave_id and action:
            status = "Approved" if action == "Approve" else "Rejected"
            cur.execute("UPDATE leave_requests SET status=? WHERE id=?", (status, leave_id))
            con.commit()
            flash(f"Leave {status}", "success")

    # Fetch all leave requests for this supervisor
    cur.execute("""
        SELECT lr.id, e.name, e.empcode, lr.leave_from, lr.leave_to, lr.reason, lr.status
        FROM leave_requests lr
        JOIN empworkers e ON lr.empcode = e.empcode
        WHERE lr.supervisor_empcode=?
        ORDER BY lr.leave_from DESC
    """, (empid,))
    leaves = cur.fetchall()
    con.close()

    return render_template("supervisor.html", name=session.get('name', 'User'), leaves=leaves)

@app.route("/emp", methods=["GET", "POST"])
def emp():
    return render_template("emp.html", name=session.get('name', 'User'))
@app.route("/about", methods=["GET", "POST"])
def about():
    return render_template("about.html")
@app.route("/att", methods=["GET", "POST"])
def att():
    return render_template("att.html")
@app.route("/contact", methods=["GET", "POST"])
def contact():
    return render_template("contact.html")

@app.route("/addemp", methods=["GET", "POST"])
def addemp():
    con = sqlite3.connect("test.db")
    cur = con.cursor()

    # ✅ Fetch both empid and name
    cur.execute("SELECT empcode, name FROM supworkers")
    supervisors = cur.fetchall()

    if request.method == "POST":
        name = request.form['name']
        empcode = request.form['empid']
        role = request.form['designation']
        gender = request.form['gender']
        doj = request.form['doj']
        blood = request.form['bldgrp']
        supervisor = request.form['supervisor']

        cur.execute(
            "INSERT INTO empworkers (name, empcode, role, gender, doj, bldgrp, supervisor) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (name, empcode, role, gender, doj, blood, supervisor)
        )
        con.commit()
        con.close()
        flash("Employee added successfully!", "success")
        return redirect(url_for("addemp"))

    con.close()
    return render_template("addemp.html", supervisors=supervisors)


@app.route("/addsup", methods=["POST", "GET"])
def addsup():
    if request.method == 'POST':
        name = request.form['name']
        empids = request.form['empid']
        role = request.form['designation']
        doj = request.form['doj']
        gender = request.form['gender']
        bldgrp = request.form['bldgrp']

        con = sqlite3.connect("test.db")
        cur = con.cursor()
        cur.execute('INSERT INTO supworkers(name, empcode, role, gender, doj, bldgrp) VALUES (?, ?, ?, ?, ?, ?)',(name, empids, role, gender, doj, bldgrp))

        con.commit()
        con.close()

        flash("Supervisor added successfully!", "success")
        return redirect(url_for("hr"))
    else:
        return render_template("addsup.html")
@app.route('/updateemp/<name>', methods=['GET', 'POST'])
def updateemp(name):
    con = sqlite3.connect('test.db')
    cur = con.cursor()

    # Fetch the employee record
    cur.execute("SELECT * FROM empworkers WHERE name=?", (name,))
    emp = cur.fetchone()

    if not emp:
        con.close()
        flash("Employee not found", "danger")
        return redirect(url_for('hr'))
    # ✅ Fetch both empid and name
    cur.execute("SELECT empcode, name FROM supworkers")
    supervisors = cur.fetchall()

    if request.method == 'POST':
        # Get form data from user edits
        new_role = request.form['role']
        new_gender = request.form['gender']
        new_doj = request.form['doj']
        new_bldgrp = request.form['bldgrp']
        supervisors = request.form['supervisor']

        # Update the employee details
        cur.execute("""
            UPDATE empworkers 
            SET role=?, gender=?, doj=?, bldgrp=?, supervisor=?
            WHERE name=?
        """, (new_role, new_gender, new_doj, new_bldgrp, supervisors, name))

        con.commit()
        con.close()
        flash("Employee details updated successfully!", "success")
        return redirect(url_for('hr'))

    con.close()
    return render_template('updateemp.html', emp=emp,supervisors=supervisors)

@app.route('/updatesup/<empcode>', methods=['GET', 'POST'])
def updatesup(empcode):
    con = sqlite3.connect('test.db')
    cur = con.cursor()

    # Fetch supervisor by empcode (unique)
    cur.execute("SELECT * FROM supworkers WHERE empcode=?", (empcode,))
    sup = cur.fetchone()

    if request.method == 'POST':
        new_role = request.form['role']
        new_gender = request.form['gender']
        new_doj = request.form['doj']
        new_bldgrp = request.form['bldgrp']

        # Update supervisor
        cur.execute("""
            UPDATE supworkers 
            SET  role=?, gender=?, doj=?, bldgrp=?
            WHERE empcode=?
        """, ( new_role, new_gender, new_doj, new_bldgrp, empcode))

        con.commit()
        con.close()
        flash("Supervisor details updated successfully!", "success")
        return redirect(url_for('hr'))

    con.close()
    return render_template('updatesup.html', sup=sup)

@app.route("/mydetails",methods=["POST","GET"])
def mydetails():
    if 'empid' not in session:
        flash("Please log in as an employee to view your details.", "warning")
        return redirect(url_for("index"))
    empid = session['empid']
    con = sqlite3.connect("test.db")
    cur = con.cursor()
    cur.execute("""
        SELECT e.name, e.empcode, e.role, e.mobile, e.email,
               w.gender, w.doj, w.bldgrp, w.supervisor
        FROM emptbl e
        JOIN empworkers w
        ON e.empcode = w.empcode
        WHERE e.empcode = ?
    """, (empid,))
    row = cur.fetchone()
    con.close()

    if not row:
        flash("Your details are not found in the database.", "danger")
        return redirect(url_for("emp"))

    emp = {
        "name": row[0],
        "empcode": row[1],
        "role": row[2],
        "mobile": row[3],
        "email": row[4],
        "gender": row[5],
        "doj": row[6],
        "bldgrp": row[7],
        "supervisor": row[8]
    }

    return render_template("mydetails.html", emp=emp)
@app.route("/deleteemp", methods=["POST", "GET"])
def deleteemp():
    if request.method == 'POST':
        name = request.form['name']
        empids = request.form['empid']
        role = request.form['designation']
        supervisor = request.form['supervisor']

        con = sqlite3.connect("test.db")
        cur = con.cursor()
        cur.execute('DELETE FROM empworkers WHERE name=? AND empcode=? AND role=? AND supervisor=?',(name, empids, role, supervisor))
        cur.execute('DELETE FROM emptbl WHERE name=? AND empcode=?',(name, empids))
        con.commit()
        con.close()

        flash("Employee deleted successfully!", "success")
        return redirect(url_for("hr"))
    else:
        return render_template("deleteemp.html")
@app.route("/deletesup", methods=["POST", "GET"])
def deletesup():
    if request.method == 'POST':
        name = request.form['name']
        empids = request.form['empid']
        role = request.form['designation']

        con = sqlite3.connect("test.db")
        cur = con.cursor()
        cur.execute('DELETE FROM supworkers WHERE name=? AND empcode=? AND role=?',(name, empids, role))
        cur.execute('DELETE FROM emptbl WHERE name=? AND empcode=?',(name, empids))
        con.commit()
        con.close()

        flash("Supervisor deleted successfully!", "success")
        return redirect(url_for("hr"))
    else:
        return render_template("deletesup.html")
@app.route("/leaverequest", methods=["POST", "GET"])
def leaverequest():
    empid = session.get('empid')
    if not empid:
        flash("Please log in to submit leave request.", "danger")
        return redirect(url_for("index"))

    if request.method == 'POST':
        leave_from = request.form['from']
        leave_to = request.form['to']
        reason = request.form['reason']

        con = sqlite3.connect("test.db")
        cur = con.cursor()

        # 1️⃣ Fetch employee details including supervisor code and email
        cur.execute("SELECT supervisor, name FROM empworkers WHERE empcode = ?", (empid,))
        emp_data = cur.fetchone()

        if not emp_data:
            flash("Employee not found.", "danger")
            con.close()
            return redirect(url_for("leaverequest"))

        supervisor_code, emp_name = emp_data

        # 2️⃣ Fetch supervisor email and name
        cur.execute("SELECT name, email FROM emptbl WHERE  role ='supervisor' AND empcode = ?", (supervisor_code,))
        sup_data = cur.fetchone()

        if not sup_data:
            # Save leave anyway
            cur.execute("""
                INSERT INTO leave_requests (empcode, supervisor_empcode, leave_from, leave_to, reason)
                VALUES (?, ?, ?, ?, ?)
            """, (empid, supervisor_code if supervisor_code else None, leave_from, leave_to, reason))
            con.commit()
            con.close()
            flash("Leave request saved but supervisor not assigned. Please contact HR.", "warning")
            return redirect(url_for("emp"))

        sup_name, supervisor_email = sup_data

        # 3️⃣ Save leave request
        cur.execute("""
            INSERT INTO leave_requests (empcode, supervisor_empcode, leave_from, leave_to, reason, status, email_sent)
            VALUES (?, ?, ?, ?, ?, 'Pending', 0)
        """, (empid, supervisor_code, leave_from, leave_to, reason))
        leave_id = cur.lastrowid
        con.commit()

        # 4️⃣ Send email using fixed HR/company Gmail
        email_ok = False
        try:
            msg = EmailMessage()
            msg['From'] = "dhanalakshmib772@gmail.com"
            msg['To'] = supervisor_email
            msg['Subject'] = f"Leave Request from {emp_name} ({empid})"
            msg.set_content(f"""
Dear {sup_name},

Your team member {emp_name} (Employee ID: {empid}) has submitted a leave request.

Leave Dates: {leave_from} to {leave_to}
Reason: {reason}


Please review this request.

Regards,
HR Portal
""")
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.login("dhanalakshmib772@gmail.com", "nfujxqwazwliawuf")  # Gmail App Password
            server.send_message(msg)
            server.quit()
            email_ok = True

        except Exception as e:
            print("Error sending email:", e)
            email_ok = False

        # 5️⃣ Update email_sent flag
        try:
            cur.execute("UPDATE leave_requests SET email_sent=? WHERE id=?", (1 if email_ok else 0, leave_id))
            con.commit()
        except Exception as e:
            print("Error updating email_sent:", e)
        finally:
            con.close()

        if email_ok:
            flash("Leave request submitted and email sent to supervisor.", "success")
        else:
            flash("Leave request saved but email could not be sent. Supervisor will be notified later.", "warning")

        return redirect(url_for("emp"))

    # GET request
    return render_template("leaverequest.html", name=session.get('name'))

@app.route("/my_leaves")
def my_leaves():
    if 'empid' not in session:
        flash("Please log in to view your leaves.", "danger")
        return redirect(url_for("index"))

    empid = session['empid']
    con = sqlite3.connect("test.db")
    cur = con.cursor()
    cur.execute("""
        SELECT leave_from, leave_to, reason, status
        FROM leave_requests
        WHERE empcode = ?
        ORDER BY leave_from DESC
    """, (empid,))
    leaves = cur.fetchall()
    con.close()
    return render_template("my_leaves.html", leaves=leaves)
'''@app.route("/att", methods=["GET", "POST"])
def att():
    if 'empid' not in session:
        flash("Please log in to view attendance.", "danger")
        return redirect(url_for("index"))

    empid = session['empid']  # employee code from session
    name = session.get('name', 'User')

    conn = sqlite3.connect("employee.db")  # or your actual DB name
    cur = conn.cursor()
    cur.execute("""
        SELECT leave_from, leave_to
        FROM leave_requests
        WHERE empcode = ? AND status = 'Approved'
    """, (empid,))
    data = cur.fetchall()
    conn.close()

    # Convert SQL data to JSON-friendly format
    leaves = [{"from": row[0], "to": row[1]} for row in data]

    # Pass name and leaves (as JSON) to template
    import json
    return render_template("att.html", name=name, leaves=json.dumps(leaves))
'''
if __name__ == '__main__':
    init_db()
    app.run(debug=True)
